
			var thisnum=-1
			var interval=-1
			var omsgarr=[]
			var isopenwx=false
			function clearCache(){
				tts("清空")
				$("#oldMsgView").html("")
			}
			function check(){
				$(document).load("ui.xml",null,function(res,sta,xhr){
					console.info("query ui.xml:"+res.length)
					$("#data").html("<div>"+res.replace(/\n/g,"</div><div>")+"</div>")
					//get si ei
					const darr=$('#data').find('div')
					
					//get msg to arr
					var msg=""
					const getmsgarr=[]
					darr.each(function(i,d){
						if(d.innerText.indexOf("库存")>=0&&i>=3){
							var msg1=""
							for(var j=3;j>=0;j--){
								const tarr=darr[i-j].innerText.split(">")
								msg1+=tarr[tarr.length-1]
								msg1+="$"
							}
							//filter 备件库","爱锋派","库存
							if(getmsgarr.indexOf(msg1)<0&&msg1.indexOf("$$")<0&&msg1.indexOf("$")!=0&&["备件库","爱锋派","库存"].filter(b=>msg1.indexOf(b)==0).length==0){
								getmsgarr.push(msg1)
								msg+=msg1
								msg+="<br>"
							}
						}
					})
					$("#allMsgView").html(msg)
					
					//new msg arr is not null
					if(getmsgarr.length>0){
						const nmsgarr=getmsgarr.filter(msg=>{
							var isNew=omsgarr.indexOf(msg)<0
							const nkcomsgarr=omsgarr.map(m=>m.split("库存")[0])
							const nkcmsg=msg.split("库存")[0]
							const nkcoindex=nkcomsgarr.indexOf(nkcmsg)
							//数量变化
							if(isNew&&nkcoindex>=0){
								const kcn=msg.split("$")[3].split(" ")[1].trim()
								//数量增加时也算更新
								if(kcn>0){
									if(kcn>omsgarr[nkcoindex].split("$")[3].split(" ")[1].trim()){
										
									}else isNew=false
								}else isNew=false
							}
							return isNew
						}).sort(function(l1,l2){
							const tmp1=l1.split("$")
							const tmp2=l2.split("$")
							const i1= tmp1.findIndex(c1=>c1.indexOf("¥")>=0)
							const i2= tmp2.findIndex(c2=>c2.indexOf("¥")>=0)
							const y1=parseFloat(tmp1[i1].split("¥")[1].replace(/ /g,""))
							const y2=parseFloat(tmp2[i2].split("¥")[1].replace(/ /g,""))
							return y1-y2
						})
						if(nmsgarr.length>0&&omsgarr.length>0) {
							//if(nmsgarr.length<20){
								var nmsgStr=""
								nmsgarr.map(msg=>{
									nmsgStr+=(msg+"<br>")
								})
								$("#oldMsgView").html(nmsgStr+"<br>"+$("#oldMsgView").html())
								$("#newMsgView").html(nmsgStr)
								tts("您有新的消息")
								$.post("http://localhost/py/set_heart"+(isopenwx?"?isopenwx=true":""),nmsgStr.replaceAll("¥","人民币"))
								//saveShareContent(nmsgStr,"nyxdxx.txt")
							//}else {//if(nmsgarr.length>20)
							//	tts("新消息数量巨大")
							//	saveShareContent(omsgarr,"omsgarr.txt")
							//	saveShareContent(getmsgarr,"getmsgarr.txt")
							//}
						}
						omsgarr=getmsgarr
					}
					
				})
			}
            function saveShareContent (content, fileName) {
                let downLink = document.createElement('a')
                downLink.download = fileName
                //字符内容转换为blod地址
                let blob = new Blob([content])
                downLink.href = URL.createObjectURL(blob)
                // 链接插入到页面
                document.body.appendChild(downLink)
                downLink.click()
                // 移除下载链接
                document.body.removeChild(downLink)
            }
			function tts(str,numb){
				//百度
				try{
					var url = "https://fanyi.baidu.com/gettts?lan=zh&text="+encodeURI(str)+"&spd=5&source=web"
					var n = new Audio(url)
					n.src = url
					n.play().then((da)=>{console.info(str)},(err)=>{
						if(numb>=10){
							console.error(err)
						}else tts(str,numb)
					})
				}catch(e){
					console.error(e.stack)
					tts(str)
				}
			}
			function switchWX(e){
				if(isopenwx){
					e.value="打开微信"
					isopenwx=false
				}else{
					e.value="关闭微信"
					isopenwx=true
				}
				
			}
			function start(e){
				if(e.value=="启动"){
					e.value="停止"
					tts("启动...")
					interval=setInterval(check,5000)
				}else{
					e.value="启动"
					console.info("停止...")
					clearInterval(interval)
				}
			}