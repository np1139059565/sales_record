wres=0
werr=0


while [ $wres -eq $werr ]
do
  sleep 1
  echo get ui to ui2.xml...
  echo "">/sdcard/lcy/data/ui2.xml
  msg=$(uiautomator dump /sdcard/lcy/data/ui2.xml)
  wres=$(echo $msg|grep "UI hierchary dumped to:"|wc -l)
done

echo "">/sdcard/lcy/data/ui2.grep
sed 's/<node/\n/g' /sdcard/lcy/data/ui2.xml |grep -v 'text=""'| awk -F 'text="' '{print $2}'|awk -F 'resource-id="' '{print $1$2}'|awk -F 'bounds="' '{print $2$1}'|awk -F '"' '{print $1$3$2}'|sed 's/,/ /g'|sed 's/<\/node>//g'>/sdcard/lcy/data/ui2.grep

#grep tv_product_type_name|tv_name|tv_product_level|tv_sku_name|tv_price|tv_product_number
echo "">/sdcard/lcy/data/ui2.text
if [ -n "$1" ]
then
  grepStr=$1
  echo grep $grepStr...
  cat /sdcard/lcy/data/ui2.grep|grep -E "$grepStr">/sdcard/lcy/data/ui2.text
else
  cat /sdcard/lcy/data/ui2.grep>/sdcard/lcy/data/ui2.text
fi
