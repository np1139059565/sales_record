wsucc=1

if [ -n "$1" ]
then
  searchStr=$1
  echo open search...
   input tap 300 150
   sleep 1;
  echo clean search...
   input  tap 800 150
   input  tap 800 150
   sleep 1;
  echo input $searchStr...
   input text "$searchStr"
   sleep 1;
  echo start search...
   input tap 1000 2200
   sleep 2;
  echo open pinglei xinghao...
   input tap 318 250
   sleep 1;
  echo filter all xinghao...
   sh /sdcard/lcy/getui.sh "tv_name"
  filterStr=$2
  echo filter $filterStr...
   cat /sdcard/lcy/data/ui2.text|grep "$filterStr">/sdcard/lcy/data/filter.text
  rindex=$3
  echo find $rindex...
   pbounds=$(sed -n $rindex'p' /sdcard/lcy/data/filter.text|awk -F ']' '{print $1}'|awk -F '[' '{print $2}')
   input tap $pbounds
  echo filter ok...
   sh /sdcard/lcy/getui.sh tv_confirm
  echo click ok...
   pbounds=$(sed -n 1'p' /sdcard/lcy/data/ui2.text|awk -F ']' '{print $1}'|awk -F '[' '{print $2}')
   input tap $pbounds
else
  echo findPhone err.
fi