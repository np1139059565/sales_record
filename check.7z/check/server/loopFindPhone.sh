wsucc=1

while true;
do
 echo "">/sdcard/lcy/data/loopFindPhone.text
 while read -r line
 do
  searchStr=$(echo $line|awk -F ',' '{print $1}')
  filterStr=$(echo $line|awk -F ',' '{print $2}')
  rindex=$(echo $line|awk -F ',' '{print $3}')
  findRes=$(sh /sdcard/lcy/findPhone.sh "$searchStr" "$filterStr" "$rindex")
  echo find res:$findRes
  
  isErr=$($findRes|grep "err."|wc -l)
  if [ $isErr -ne $wsucc ]
  then
   sh /sdcard/lcy/filterui.sh
   cat /sdcard/lcy/data/ui4.text>>/sdcard/lcy/data/loopFindPhone.text
  else
   echo loopFindPhone err.
  fi
 done < /sdcard/lcy/data/finds.text
 
 cat /sdcard/lcy/data/loopFindPhone.text>/sdcard/lcy/data/loopRes.text
 sleep 3;
done