p=p
parseConter(){
  echo get conter1 to bak4.text...
  cat /sdcard/lcy/data/ui2.text>/sdcard/lcy/data/bak44.text
  cat /sdcard/lcy/data/bak44.text|grep -n 库存|awk -F ':' '{print $1}'>/sdcard/lcy/data/kcn4.text
  for n in $(cat /sdcard/lcy/data/kcn4.text)
  do
    sed -n $(($n-3)),$n$p /sdcard/lcy/data/bak44.text>>/sdcard/lcy/data/bak4.text
  done
}

rm /sdcard/lcy/data/bak4.text

sh /sdcard/lcy/getui.sh "tv_product_level|tv_sku_name|tv_price|tv_product_number|tv_footer_tips"
fl=$(cat /sdcard/lcy/data/ui2.text|grep "/tv_footer_tips"|wc -l)

while [[ $fl != 1 ]]
do
  parseConter
  echo swipe...
  input swipe 400 2000 400 1200
  sh /sdcard/lcy/getui.sh "tv_product_level|tv_sku_name|tv_price|tv_product_number|tv_footer_tips"
  fl=$(cat /sdcard/lcy/data/ui2.text|grep "/tv_footer_tips"|wc -l)
done

parseConter

echo all conter1 to ui4.text
cat /sdcard/lcy/data/bak4.text>/sdcard/lcy/data/ui4.text